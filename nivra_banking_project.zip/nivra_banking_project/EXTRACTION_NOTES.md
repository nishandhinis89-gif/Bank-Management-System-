# Extraction Notes

Source: Appendix A (Code Snippets), report pages 24-34, of the Bank Management System report.

`app.py` is the full code printed in the report, in original order. The PDF text had lost its
indentation and some lines were wrapped, so indentation and line breaks were restored from
Python syntax. No logic, names, or structure were changed.

## Things that are NOT in the PDF (so not in this folder)
- `tables` list used by `initialize_database()` (the CREATE TABLE statements) is never defined
  in the report. Tables seen in the code: app_users, customers, accounts, transactions,
  fixed_deposits, loans.
- The `frontend/` HTML templates (login.html, register.html, dashboard.html, customers.html,
  accounts.html, transactions.html, fixed_deposits.html, loans.html, reports.html,
  assistant.html) and the `static/` folder. Only screenshots exist (Appendix B).
- The end of `analytics()`: the report's code stops after its third query (no return statement).
- `reports()` and `assistant()` appear in the report without their `@app.route(...)` /
  `@login_required` decorator lines.
- Routes for deposit/withdraw pages, debit cards, and fund transfer seen in the screenshots
  are not in the printed code.

## Left exactly as printed
All of the above gaps are kept as they appear in the report.
