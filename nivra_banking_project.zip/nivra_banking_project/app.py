# NIVRA AI Predictive Banking System
import os, random
from datetime import date, timedelta
from functools import wraps
from flask import *
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
app = Flask(__name__, template_folder="frontend", static_folder="static")
app.secret_key = os.getenv("FLASK_SECRET_KEY", "secret")
DB = {"host":"localhost","user":"root","password":os.getenv("DB_PASSWORD",""),"database":"nivra_banking"}
def db():
    return mysql.connector.connect(**DB)
def login_required(fn):
    @wraps(fn)
    def wrapper(*a,**k):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*a,**k)
    return wrapper
def account_no():
    return "NIVRA"+str(random.randint(100000,999999))
def emi(a,r,n):
    r=r/1200
    if a<=0 or n<=0:
        return 0
    return round(a/n if r==0 else a*r*(1+r)**n/((1+r)**n-1),2)
def fd_maturity(a,r,n):
    return round(a*(1+r/400)**(n/3),2)
def initialize_database():
    con=db()
    cur=con.cursor()
    for sql in tables:
        cur.execute(sql)
    con.commit()
    cur.close()
    con.close()
@app.route("/")
def home():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))
@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        n=request.form.get("full_name","").strip()
        e=request.form.get("email","").strip().lower()
        p=request.form.get("password","")
        if n and e and len(p)>=8:
            con=db()
            cur=con.cursor()
            cur.execute("INSERT INTO app_users(full_name,email,password_hash) VALUES(%s,%s,%s)",(n,e,generate_password_hash(p)))
            con.commit()
            cur.close()
            con.close()
            return redirect(url_for("login"))
        flash("Invalid details","error")
    return render_template("register.html")
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        con=db()
        cur=con.cursor(dictionary=True)
        cur.execute("SELECT * FROM app_users WHERE email=%s",(request.form.get("email","").lower(),))
        u=cur.fetchone()
        cur.close()
        con.close()
        if u and check_password_hash(u["password_hash"],request.form.get("password","")):
            session.clear()
            session["user_id"]=u["user_id"]
            session["user_name"]=u["full_name"]
            return redirect(url_for("dashboard"))
        flash("Invalid login","error")
    return render_template("login.html")
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))
@app.route("/dashboard")
@login_required
def dashboard():
    con=db()
    cur=con.cursor(dictionary=True)
    q={"total_customers":"SELECT COUNT(*) n FROM customers","total_accounts":"SELECT COUNT(*) n FROM accounts","total_balance":"SELECT COALESCE(SUM(balance),0) n FROM accounts","total_transactions":"SELECT COUNT(*) n FROM transactions"}
    data={}
    for k,s in q.items():
        cur.execute(s)
        data[k]=cur.fetchone()["n"]
    cur.close()
    con.close()
    return render_template("dashboard.html",**data)
@app.route("/customers",methods=["GET","POST"])
@login_required
def customers():
    con=db()
    cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cur.execute("INSERT INTO customers(full_name,email,phone,address) VALUES(%s,%s,%s,%s)",(request.form.get("full_name"),request.form.get("email"),request.form.get("phone"),request.form.get("address")))
        con.commit()
    cur.execute("SELECT * FROM customers ORDER BY customer_id DESC")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return render_template("customers.html",customers=rows)
@app.route("/accounts",methods=["GET","POST"])
@login_required
def accounts():
    con=db()
    cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cur.execute("INSERT INTO accounts(customer_id,account_number,account_type,balance) VALUES(%s,%s,%s,0)",(request.form.get("customer_id"),account_no(),request.form.get("account_type","Savings")))
        con.commit()
    cur.execute("SELECT a.*,c.full_name FROM accounts a JOIN customers c USING(customer_id)")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return render_template("accounts.html",accounts=rows)
@app.route("/transactions",methods=["GET","POST"])
@login_required
def transactions():
    con=db()
    cur=con.cursor(dictionary=True)
    if request.method=="POST":
        aid=request.form.get("account_id",type=int)
        amt=request.form.get("amount",type=float)
        kind=request.form.get("transaction_type")
        cur.execute("SELECT balance,status FROM accounts WHERE account_id=%s FOR UPDATE",(aid,))
        acc=cur.fetchone()
        if acc and acc["status"]=="Active" and amt and amt>0:
            bal=float(acc["balance"])
            if kind=="Deposit":
                bal+=amt
            elif kind=="Withdraw" and bal>=amt:
                bal-=amt
            else:
                flash("Invalid transaction","error")
                bal=None
            if bal is not None:
                cur.execute("UPDATE accounts SET balance=%s WHERE account_id=%s",(bal,aid))
                cur.execute("INSERT INTO transactions(account_id,transaction_type,amount) VALUES(%s,%s,%s)",(aid,kind,amt))
                con.commit()
    cur.execute("SELECT * FROM transactions ORDER BY transaction_date DESC")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return render_template("transactions.html",transactions=rows)
@app.route("/fixed-deposits",methods=["GET","POST"])
@login_required
def fixed_deposits():
    con=db()
    cur=con.cursor(dictionary=True)
    if request.method=="POST":
        aid=request.form.get("account_id",type=int)
        amt=request.form.get("amount",type=float)
        n=request.form.get("tenure",type=int)
        rate={6:6.5,12:7.25,24:7.5,36:8,60:8.5}.get(n,6.5)
        cur.execute("SELECT customer_id,balance FROM accounts WHERE account_id=%s",(aid,))
        acc=cur.fetchone()
        if acc and amt and amt>=1000 and float(acc["balance"])>=amt:
            m=fd_maturity(amt,rate,n)
            cur.execute("UPDATE accounts SET balance=balance-%s WHERE account_id=%s",(amt,aid))
            cur.execute("INSERT INTO fixed_deposits(account_id,customer_id,principal_amount,interest_rate,tenure_months,maturity_amount,start_date,maturity_date) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",(aid,acc["customer_id"],amt,rate,n,m,date.today(),date.today()+timedelta(days=30*n)))
            con.commit()
    cur.execute("SELECT * FROM fixed_deposits")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return render_template("fixed_deposits.html",fds=rows)
@app.route("/loans",methods=["GET","POST"])
@login_required
def loans():
    con=db()
    cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cid=request.form.get("customer_id",type=int)
        amt=request.form.get("amount",type=float)
        n=request.form.get("tenure",type=int)
        rate=8.5
        cur.execute("INSERT INTO loans(customer_id,amount,purpose,interest_rate,tenure_months,monthly_emi) VALUES(%s,%s,%s,%s,%s,%s)",(cid,amt,request.form.get("purpose"),rate,n,emi(amt,rate,n)))
        con.commit()
    cur.execute("SELECT * FROM loans ORDER BY loan_id DESC")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return render_template("loans.html",loans=rows)
@app.route("/analytics")
@login_required
def analytics():
    con=db()
    cur=con.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) total,COALESCE(AVG(amount),0) average FROM transactions")
    stats=cur.fetchone()
    cur.execute("SELECT * FROM transactions WHERE amount>10000")
    flagged=cur.fetchall()
    cur.execute("SELECT COALESCE(SUM(balance),0) balance FROM accounts")
def reports():
    con=db()
    cur=con.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) customers FROM customers")
    total=cur.fetchone()["customers"]
    cur.execute("SELECT COUNT(*) accounts,COALESCE(SUM(balance),0) balance FROM accounts")
    data=cur.fetchone()
    ledger=cur.fetchall()
    return render_template("reports.html",total_customers=total,total_accounts=data["accounts"],total_balance=data["balance"],ledger=ledger)
def assistant():
    q=request.form.get("question","").lower()
    a="Ask about accounts, balance, FD, EMI or loans."
    if "fd" in q or "fixed deposit" in q:
        a="FD rates depend on tenure."
    elif "emi" in q or "loan" in q:
        a="EMI depends on amount, rate and tenure."
    elif "balance" in q:
        a="Check balance on the Accounts page."
    return render_template("assistant.html",question=q,answer=a)
@app.route("/api/chart-data")
@login_required
def chart_data():
    con=db()
    cur=con.cursor(dictionary=True)
    cur.execute("SELECT DATE(transaction_date) day,transaction_type,SUM(amount) total FROM transactions WHERE transaction_date>=CURDATE()-INTERVAL 6 DAY GROUP BY day,transaction_type")
    rows=cur.fetchall()
    cur.close()
    con.close()
    return jsonify(rows)
if __name__=="__main__":
    initialize_database()
    app.run(debug=True)
